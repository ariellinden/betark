* sim8.do

clear all
set more off

local reps        2000
local cv          .05
local step1       0
local baseseed    500000

local T    200
local trp = `T'/2
local lag  1
local rho1opt "rho1(0.4)"

local interceptlist "0.05 0.10 0.30 0.50"
local pretrendlist  "0 25 -25"
local trtlist       "0 50"

tempname mc
postfile `mc' intercept pretrendpct trendpct rep b_post_true		///
              conv_betark b_betark se_betark						///
              conv_glm b_glm se_glm								///
              using "E:\ArielStuff\betark_sims\sim8.dta", replace

foreach icpt of local interceptlist {
	foreach pretr of local pretrendlist {
		foreach trt of local trtlist {

			di as txt _newline "intercept=`icpt' pretrend=`pretr'% trend=`trt'%: running `reps' reps"
			_dots 0 0

			forvalues r = 1/`reps' {

				local icpt100 = round(`icpt'*100)
				local thisseed = `baseseed' + `icpt100'*100000 + (`pretr'+25)*1000 + `trt'*10 + `r'

				quietly betarkdgp, ntime(`T') trperiod1(`trp') intercept(`icpt')	///
					pretrend(`pretr') step1(`step1') posttrend1(`trt')				///
					cv(`cv') `rho1opt' seed(`thisseed')

				local b_post_true = r(b_post1) - r(b_pre)

				quietly tsset t

				betarksimfit, trperiod1(`trp') lagbetark(`lag') lagglm(`lag')

				local failed = (r(conv_betark) == 0 & r(conv_glm) == 0)
				_dots `r' `failed'

				post `mc' (`icpt') (`pretr') (`trt') (`r') (`b_post_true')	///
				          (r(conv_betark)) (r(b_betark)) (r(se_betark))	///
				          (r(conv_glm)) (r(b_glm)) (r(se_glm))
			}
		}
	}
}

postclose `mc'

di as txt _newline "Done. Saved to sim8.dta"
